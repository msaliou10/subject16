#include <stdlib.h>
#include <stdio.h>

int ft_strlen(char *str)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return (i);
}

/* 
while (strs[i] < size)
    {
        j += ft_strlen(strs[i]);
        while (sep[k] != '\0' && i < (size - 1))
        {
            strs[j + (i + 1)] = sep[i];
            k++;
        }
        j += k;
        k = 0;
        i++;
    }
 */

char *concat(int size, char *strs, char *sep)
{
    int i;
    int j;
    int k;

    i = 0;
    j = 0;
    k = 0;
    while (strs[i] < size)
    {
        j += ft_strlen(strs[i]);
        if(i < (size - 1))
        {
            while (sep[k] != '\0')
            {
                strs[++j] = sep[i];
                k++;
            }
            k = 0;
            i++;
        }
    }
    return strs;
}

char *ft_strjoin(int size, char *strs, char *sep)
{
    int i;
    int count;
    char *str;

    i = 0;
    count = 0;
    if(size <= 0)
        return (NULL);
    while (i < size)
    {
        count += ft_strlen(strs[i]);
        i++;
        if(i < (size - 1))
            count += ft_strlen(sep);
    }
    str = malloc(sizeof(char) * (count + 1));
    if(str == NULL)
        return (NULL);
    str = concat(size, strs, sep);
    return str;
}

int main(void)
{
    char *strs[] = {"Hello", "42", "pisciners"};
    printf("%s\n", ft_strjoin(3, strs, ", "));
    return (0);
}
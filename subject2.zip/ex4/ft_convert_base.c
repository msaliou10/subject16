#include <stdio.h>

int is_duplicate(char *str)
{
    int i;
    int j;

    i = 0;
    j = 0;
    while (str[i] != '\0')
    {
        while (str[j] != '\0')
        {
            if(str[i] == str[j] && i != j)
                return (0);
            j++;
        }
        j = 0;
        i++;
    }
    return (1);
}

int ft_strlen(char *str)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return (i);
}

int is_valid_base(char *base)
{
    if(ft_strlen(base) >= 2)
    {
        if(ft_strcontain(base, '+'))
            return (0);
        else if(ft_strcontain(base, '-'))
            return (0);
        else if(ft_strcontain(base, ' '))
            return (0);
        else
        {
            if(is_duplicate(base) == 0)
                return (0);
            return (1);
        }
    }
    return (0);
}

int ft_strcontain(char *str, char c)
{
    int i;

    i = 0;
    while (str[i] != '\0')
    {
        if(str[i] == c)
            return (1);
        i++;
    }
    return (0);
}

int get_position(char *base, char c)
{
    int i;

    i = 0;
    while (base[i] != '\0')
    {
        if(base[i] == c)
            return (i);
        i++;
    }
    return (-1);
}